// app/page.tsx
export default function Page() {
  return (
    <div>
      <h1>Pictures in Ceramic</h1>
      <p>Premium enamel memorial cameos since 1993.</p>
    </div>
  );
}
